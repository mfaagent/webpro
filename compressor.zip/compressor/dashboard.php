<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$compressed_dir = 'compressed/';
$files = array_diff(scandir($compressed_dir), array('.', '..'));
$files = array_values($files); // Reset indeks array agar no urut benar
?>

<!DOCTYPE html>
<html lang="id" >
<head>
    <meta charset="UTF-8" />
    <title>Dashboard</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white min-h-screen p-8 flex flex-col">

    <header class="mb-10 flex justify-between items-center">
        <h1 class="text-4xl font-extrabold tracking-tight">Dashboard User: <span class="text-green-400"><?= htmlspecialchars($_SESSION['user']) ?></span> Metode Kompresi Lz77</h1>
        <form action="logout.php" method="POST">
            <button type="submit" 
                class="bg-red-600 hover:bg-red-700 px-4 py-2 rounded font-semibold transition">Logout</button>
        </form>
    </header>

    <!-- Form Upload File -->
    <section class="mb-12 max-w-2xl w-full mx-auto">
        <h2 class="text-3xl font-semibold mb-6 border-b border-gray-700 pb-2">Upload & Kompres File</h2>
        <form action="compress.php" method="POST" enctype="multipart/form-data" class="flex gap-4 items-center">
            <input 
                type="file" 
                name="file" 
                required
                class="text-gray-900 rounded-md px-4 py-2 w-full"
                accept=".txt,.pdf,.png,.jpg,.jpeg,.zip"
            />
            <button type="submit" class="bg-green-600 hover:bg-green-700 px-6 py-2 rounded-md font-semibold transition">Kompres</button>
        </form>
    </section>

    <!-- Daftar File Hasil Kompresi -->
    <section class="max-w-4xl w-full mx-auto">
        <h2 class="text-3xl font-semibold mb-6 border-b border-gray-700 pb-2">Daftar File Hasil Kompresi</h2>

        <?php if (count($files) === 0): ?>
            <p class="text-gray-400 italic">Belum ada file hasil kompresi.</p>
        <?php else: ?>
            <div class="overflow-x-auto rounded-lg border border-gray-700">
                <table class="min-w-full text-left text-sm font-medium">
                    <thead class="bg-gray-800 text-gray-300 uppercase tracking-wide">
                        <tr>
                            <th class="px-5 py-3 w-14">No</th>
                            <th class="px-5 py-3">Nama File</th>
                            <th class="px-5 py-3 w-28">Ukuran</th>
                            <th class="px-5 py-3 w-48">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($files as $idx => $file):
                            $filepath = $compressed_dir . $file;
                            $filesize = filesize($filepath);
                            $size_readable = $filesize > 1024 ? number_format($filesize / 1024, 2) . ' KB' : $filesize . ' B';
                            $no = $idx + 1;
                        ?>
                        <tr class="<?= $no % 2 === 0 ? 'bg-gray-800' : 'bg-gray-700' ?> hover:bg-gray-600 transition">
                            <td class="px-5 py-3 align-top"><?= $no ?></td>
                            <td class="px-5 py-3 break-words max-w-xs"><?= htmlspecialchars($file) ?></td>
                            <td class="px-5 py-3"><?= $size_readable ?></td>
                            <td class="px-5 py-3 space-x-3">
                                <a href="download.php?file=<?= urlencode($file) ?>" 
                                   class="inline-block bg-green-600 hover:bg-green-700 px-4 py-1 rounded-md text-sm font-semibold transition">Download</a>
                                <a href="decompress.php?file=<?= urlencode($file) ?>" 
                                   class="inline-block bg-blue-600 hover:bg-blue-700 px-4 py-1 rounded-md text-sm font-semibold transition">Dekompresi</a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </section>

</body>
</html>
