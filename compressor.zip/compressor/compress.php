<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

// Fungsi kompresi LZ77 sama seperti sebelumnya (versi biner)
function compress_lz77_bytes($data, $windowSize = 2048, $lookahead = 15) {
    $dataBytes = unpack('C*', $data);
    $dataLen = count($dataBytes);
    $i = 1;
    $output = [];

    while ($i <= $dataLen) {
        $match = ['offset' => 0, 'length' => 0];
        $start = max(1, $i - $windowSize);
        $window = array_slice($dataBytes, $start - 1, $i - $start);

        for ($j = 1; $j <= $lookahead && ($i + $j - 1) <= $dataLen; $j++) {
            $str = array_slice($dataBytes, $i - 1, $j);
            $pos = find_match_position($window, $str);
            if ($pos !== false) {
                $match['offset'] = $i - ($start + $pos);
                $match['length'] = $j;
            } else {
                break;
            }
        }

        if ($match['length'] > 0) {
            $nextByte = ($i + $match['length'] <= $dataLen) ? $dataBytes[$i + $match['length']] : null;
            $output[] = [$match['offset'], $match['length'], $nextByte];
            $i += $match['length'] + 1;
        } else {
            $output[] = [0, 0, $dataBytes[$i]];
            $i++;
        }
    }
    return $output;
}

function find_match_position($window, $pattern) {
    $windowLen = count($window);
    $patLen = count($pattern);
    for ($i = 0; $i <= $windowLen - $patLen; $i++) {
        if (array_slice($window, $i, $patLen) === $pattern) {
            return $i;
        }
    }
    return false;
}

function huffman_encode($lz_output) {
    return base64_encode(json_encode($lz_output));
}

$allowed_types = [
    'text/plain',
    'application/octet-stream',
    'application/pdf',
    'image/png',
    'image/jpeg',
    'application/zip',
];
$max_file_size = 10 * 1024 * 1024; // 10 MB

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_FILES['file'])) {
    $file = $_FILES['file'];
    if ($file['error'] === UPLOAD_ERR_OK) {

        if (!in_array($file['type'], $allowed_types)) {
            die("Tipe file tidak diizinkan.");
        }

        if ($file['size'] > $max_file_size) {
            die("Ukuran file terlalu besar. Maksimum 10MB.");
        }

        $content = file_get_contents($file['tmp_name']);
        if ($content === false) {
            die("Gagal membaca file.");
        }

        $lz77 = compress_lz77_bytes($content);
        $compressed = huffman_encode($lz77);

        $filename_clean = preg_replace('/[^a-zA-Z0-9_-]/', '_', pathinfo($file['name'], PATHINFO_FILENAME));
        $original_ext = pathinfo($file['name'], PATHINFO_EXTENSION);

        if (!is_dir('compressed')) {
            mkdir('compressed', 0777, true);
        }

        // Simpan hasil compress sebagai JSON dengan metadata filename asli + extension asli
        $save_data = json_encode([
            'filename' => $filename_clean . ($original_ext ? '.' . $original_ext : ''),
            'data' => $lz77
        ]);

        $savePath = 'compressed/' . $filename_clean . '.zst.txt';

        if (file_put_contents($savePath, base64_encode($save_data)) === false) {
            die("Gagal menyimpan file terkompresi.");
        }

        // Simpan nama file hasil compress di session (bisa diganti pakai DB)
        $_SESSION['compressed_files'][] = basename($savePath);

        // Redirect ke dashboard
        header("Location: dashboard.php");
        exit;
    } else {
        die("Upload gagal: " . $file['error']);
    }
} else {
    die("Invalid request");
}
?>
