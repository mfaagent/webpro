<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

$file = $_GET['file'] ?? '';
$file = basename($file); // amankan nama file agar tidak directory traversal

$filepath = "compressed/" . $file;

if (!file_exists($filepath)) {
    die("File tidak ditemukan!");
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <title>Download File Kompresi</title>
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-900 text-white min-h-screen flex items-center justify-center p-4">

    <div class="bg-gray-800 p-6 rounded-xl max-w-lg text-center shadow-lg">
        <h1 class="text-2xl font-semibold mb-4">File Berhasil Dikompresi</h1>
        <p class="mb-6">File: <strong><?= htmlspecialchars($file) ?></strong></p>

        <a href="download_file.php?file=<?= urlencode($file) ?>"
           class="inline-block bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded">
           Download File
        </a>

        <div class="mt-8">
            <a href="decompress.php?file=<?= urlencode($file) ?>" 
               class="inline-block bg-blue-600 hover:bg-blue-700 text-white font-bold py-2 px-6 rounded">
               Dekompresi File Ini
            </a>
        </div>

        <div class="mt-6">
            <a href="dashboard.php" class="text-gray-400 hover:text-white">Kembali ke Dashboard</a>
        </div>
    </div>

</body>
</html>
