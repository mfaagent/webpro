<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: index.php");
    exit;
}

function decompress_lz77_bytes($lz_output) {
    $outputBytes = [];
    $i = 0;
    $len = count($lz_output);

    while ($i < $len) {
        list($offset, $length, $nextByte) = $lz_output[$i];
        if ($offset === 0 && $length === 0) {
            $outputBytes[] = $nextByte;
        } else {
            $startPos = count($outputBytes) - $offset;
            for ($j = 0; $j < $length; $j++) {
                $outputBytes[] = $outputBytes[$startPos + $j];
            }
            if ($nextByte !== null) {
                $outputBytes[] = $nextByte;
            }
        }
        $i++;
    }

    return pack('C*', ...$outputBytes);
}

if (!isset($_GET['file'])) {
    die("File tidak ditentukan.");
}

$filename = basename($_GET['file']);
$filepath = __DIR__ . '/compressed/' . $filename;

if (!file_exists($filepath)) {
    die("File tidak ditemukan.");
}

$compressed_base64 = file_get_contents($filepath);
if ($compressed_base64 === false) {
    die("Gagal membaca file terkompresi.");
}

$decoded_json = base64_decode($compressed_base64);
if ($decoded_json === false) {
    die("Gagal decode base64.");
}

$data = json_decode($decoded_json, true);
if ($data === null || !isset($data['filename']) || !isset($data['data'])) {
    die("File terkompresi tidak valid.");
}

$decompressed_data = decompress_lz77_bytes($data['data']);
$original_filename = $data['filename'];

// Kirim file ke browser untuk di-download langsung
header('Content-Description: File Transfer');
header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . basename($original_filename) . '"');
header('Expires: 0');
header('Cache-Control: must-revalidate');
header('Pragma: public');
header('Content-Length: ' . strlen($decompressed_data));
echo $decompressed_data;
exit;
